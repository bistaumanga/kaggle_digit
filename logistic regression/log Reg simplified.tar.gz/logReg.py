import numpy as np
from Activation import sigmoid
from sys import *

def logRegCost(X, y, theta, regLambda = 0.0,  activation = sigmoid().h):
	''' returns the cost and gradient terms of Linear Regression'''

	m = X.shape[0]
	theta = np.matrix(theta)
	h = activation(X * theta)
	theta2 = np.vstack(([[0]],theta[1:]))
	J = -1.0 / m * (np.transpose(y)* np.log(h)  + \
			(1 - np.transpose(y)) * np.log(1 - h)) + \
			0.5 * regLambda / m * np.transpose(theta2) * theta2
	grad = 1.0 / m * (np.transpose(X) * (h - y)) + \
			(regLambda / m * theta2)
	return float(J[0][0]), grad

def trainOneVsAllGD(X, y, numClasses, act = sigmoid().h, \
						epochs = 10000, lr = 0.5, regLambda = 0.0):
	m, n = X.shape
	K = numClasses
	
	from functools import partial
	from copy import deepcopy
	model= np.matrix(np.zeros((n, K)))
	J = np.matrix(np.zeros((K, epochs)))

	for k in range(K):
		yk = (y == k)
		theta_init = np.matrix(np.zeros((n, 1)))
		# Gradient Descent
		for i in range(epochs):
			J[k, i], gradTheta = logRegCost(X, yk, theta_init, \
									regLambda, act)
			theta_init -= lr * gradTheta
		#print k, np.transpose(theta_init)
		model[:, k] = theta_init
	return model, J

def predictMultiple(model, X, act = sigmoid().h):
	return np.argmax(act(X * model), axis = 1)