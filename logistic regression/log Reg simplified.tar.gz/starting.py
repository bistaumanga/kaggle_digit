import csv as csv 
import numpy as np
import Activation, logReg

factor = 1.0/255
#################################################################
# reading from csv
print 'Loading Training Data'
csv_train = csv.reader(open('../data/train.csv', 'rb'))
header = csv_train.next()
data = np.matrix([row for row in csv_train])
trainX, train_y = factor * np.float16(data[:, 1:]), np.uint8(data[:, 0])

#################################################################
# PCA of training set
print 'Performing Principal Component Analysis'
import npPCA
trainX, U_reduced = npPCA.PCA(trainX, varRetained = 0.95, show = False)

#################################################################
# load testing data
print 'Loading test data'
csv_test = csv.reader(open('../data/test.csv', 'rb'))
header = csv_test.next()
test = factor * np.float16(np.matrix([row for row in csv_test]))

testZ = test * U_reduced
trainZ = np.hstack((np.ones((trainX.shape[0], 1)), trainX))
testZ = np.hstack((np.ones((testZ.shape[0], 1)), testZ))

#################################################################
######## TRAINING USING LOGISTIC REGRESSION #####################

print 'Training Started'
act = Activation.sigmoid().h
model, J = logReg.trainOneVsAllGD(trainZ, train_y, 10, \
				 act, epochs = 200, lr = 0.5, regLambda = 0.003)
print 'Training Ended'
#print model
import matplotlib.pyplot as plt
plt.plot(np.transpose(J))
plt.xlabel('epochs')
plt.ylabel('Cost')
plt.legend(['0','1', '2', '3', '4', '5', '6', '7', '8', '9'])
plt.show()
################################################################
print 'Predicting for test data'
test_y = logReg.predictMultiple(model, testZ, act)
print 'Writing predictions to File'
np.savetxt("../sub/logReg.csv", test_y, delimiter=",", fmt = '%d')
print 'OutPut Written to File'
