import numpy as np
import matplotlib.pyplot as plt

#############################################################################
######### Sigmoid Activation Class #######################################
class sigmoid:
	def __init__(self, k = 1):
		if k <= 0:
			k = 1
		self.k = k

	def h(self, a):
		a = np.matrix(a)
		return 1.0 / (1 + np.exp(-self.k * a))

	def dh(self, a):
		a = np.matrix(a)
		return self.k * np.multiply(self.h(a), 1 - self.h(a))

	def view(self, x = np.arange(-10, 10, 0.1)):
		x = np.array(x)
		hx = np.array(self.h(x))[0]
		dhx = np.array(self.dh(x))[0]
		plt.plot(x, hx, 'r', x, dhx, 'b')
		plt.show()